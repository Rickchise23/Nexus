/**
 * useHAStream — Real-time Home Assistant Hook
 * ==============================================
 * Subscribes to /api/ha/stream (SSE) for instant state updates.
 * Falls back to polling if the stream isn't available.
 *
 * Usage:
 *   const { entities, connected, toggle, callService } = useHAStream();
 */

"use client";

import { useState, useEffect, useCallback, useRef } from "react";

export interface HAStreamEntity {
  entity_id: string;
  state: string;
  attributes: Record<string, any>;
  last_changed?: string;
}

interface UseHAStreamReturn {
  entities: HAStreamEntity[];
  connected: boolean;
  streaming: boolean;
  error: string | null;
  toggle: (entityId: string) => Promise<void>;
  turnOn: (entityId: string, data?: Record<string, any>) => Promise<void>;
  turnOff: (entityId: string) => Promise<void>;
  callService: (domain: string, service: string, data?: Record<string, any>) => Promise<void>;
  activateScene: (sceneEntityId: string) => Promise<void>;
  setClimate: (entityId: string, temperature: number) => Promise<void>;
}

export function useHAStream(): UseHAStreamReturn {
  const [entities, setEntities] = useState<HAStreamEntity[]>([]);
  const [connected, setConnected] = useState(false);
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const sourceRef = useRef<EventSource | null>(null);
  const fallbackRef = useRef<NodeJS.Timeout | null>(null);

  // ─── SSE Connection ────────────────────────────────────────

  useEffect(() => {
    let retryCount = 0;
    const maxRetries = 3;

    const connect = () => {
      try {
        const source = new EventSource("/api/ha/stream");
        sourceRef.current = source;

        source.onopen = () => {
          retryCount = 0;
          setStreaming(true);
          setError(null);
        };

        source.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);

            if (data.type === "full") {
              setEntities(data.entities);
              setConnected(true);
            } else if (data.type === "diff") {
              setEntities((prev) => {
                const updated = [...prev];
                data.entities.forEach((changed: HAStreamEntity) => {
                  const idx = updated.findIndex((e) => e.entity_id === changed.entity_id);
                  if (idx >= 0) {
                    updated[idx] = changed;
                  } else {
                    updated.push(changed);
                  }
                });
                return updated;
              });
            } else if (data.type === "error") {
              setError(data.message);
            }
            // heartbeat — just keeps the connection alive, no action needed
          } catch {
            // ignore parse errors
          }
        };

        source.onerror = () => {
          source.close();
          setStreaming(false);

          if (retryCount < maxRetries) {
            retryCount++;
            setTimeout(connect, 2000 * retryCount);
          } else {
            // Fall back to polling
            startPolling();
          }
        };
      } catch {
        startPolling();
      }
    };

    const startPolling = () => {
      setStreaming(false);
      const poll = async () => {
        try {
          const res = await fetch("/api/ha?action=states");
          if (res.ok) {
            const data = await res.json();
            if (Array.isArray(data)) {
              setEntities(data.map((e: any) => ({
                entity_id: e.entity_id,
                state: e.state,
                attributes: e.attributes,
                last_changed: e.last_changed,
              })));
              setConnected(true);
            }
          } else {
            setConnected(false);
          }
        } catch {
          setConnected(false);
        }
      };

      poll();
      fallbackRef.current = setInterval(poll, 5000);
    };

    connect();

    return () => {
      sourceRef.current?.close();
      if (fallbackRef.current) clearInterval(fallbackRef.current);
    };
  }, []);

  // ─── Actions ──────────────────────────────────────────────

  const postAction = useCallback(async (body: Record<string, any>) => {
    const res = await fetch("/api/ha", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.error || "Action failed");
    }
    // If not streaming, manually refresh
    if (!sourceRef.current || sourceRef.current.readyState !== EventSource.OPEN) {
      const statesRes = await fetch("/api/ha?action=states");
      if (statesRes.ok) {
        const data = await statesRes.json();
        if (Array.isArray(data)) {
          setEntities(data.map((e: any) => ({
            entity_id: e.entity_id,
            state: e.state,
            attributes: e.attributes,
            last_changed: e.last_changed,
          })));
        }
      }
    }
  }, []);

  const toggle = useCallback(
    (entityId: string) => postAction({ action: "toggle", entity_id: entityId }),
    [postAction]
  );

  const turnOn = useCallback(
    (entityId: string, data?: Record<string, any>) => postAction({ action: "turn_on", entity_id: entityId, data }),
    [postAction]
  );

  const turnOff = useCallback(
    (entityId: string) => postAction({ action: "turn_off", entity_id: entityId }),
    [postAction]
  );

  const callService = useCallback(
    (domain: string, service: string, data?: Record<string, any>) =>
      postAction({ action: "call_service", domain, service, data }),
    [postAction]
  );

  const activateScene = useCallback(
    (sceneEntityId: string) => postAction({ action: "call_service", domain: "scene", service: "turn_on", data: { entity_id: sceneEntityId } }),
    [postAction]
  );

  const setClimate = useCallback(
    (entityId: string, temperature: number) =>
      postAction({ action: "set_climate", entity_id: entityId, data: { temperature } }),
    [postAction]
  );

  return {
    entities,
    connected,
    streaming,
    error,
    toggle,
    turnOn,
    turnOff,
    callService,
    activateScene,
    setClimate,
  };
}
