/**
 * useHA — React Hooks for Home Assistant
 * ========================================
 * Client-side hooks that talk to /api/ha (never touches HA directly).
 *
 * Usage:
 *   const { entities, loading, connected, toggle, callService, refresh } = useHA();
 */

"use client";

import { useState, useEffect, useCallback, useRef } from "react";

// ─── Types ───────────────────────────────────────────────────────────────────

export interface HAEntity {
  entity_id: string;
  state: string;
  attributes: Record<string, any>;
  last_changed: string;
  last_updated: string;
}

interface UseHAReturn {
  entities: HAEntity[];
  loading: boolean;
  connected: boolean;
  configured: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  toggle: (entityId: string) => Promise<void>;
  turnOn: (entityId: string, data?: Record<string, any>) => Promise<void>;
  turnOff: (entityId: string) => Promise<void>;
  callService: (domain: string, service: string, data?: Record<string, any>) => Promise<void>;
  setClimate: (entityId: string, temperature: number, hvacMode?: string) => Promise<void>;
  lock: (entityId: string) => Promise<void>;
  unlock: (entityId: string) => Promise<void>;
  getEntitiesByDomain: (domain: string) => HAEntity[];
  getEntitiesByArea: (area: string) => HAEntity[];
}

// ─── Hook ────────────────────────────────────────────────────────────────────

export function useHA(pollIntervalMs: number = 5000): UseHAReturn {
  const [entities, setEntities] = useState<HAEntity[]>([]);
  const [loading, setLoading] = useState(true);
  const [connected, setConnected] = useState(false);
  const [configured, setConfigured] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // ─── Fetch all states ──────────────────────────────────────────

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/ha?action=states");
      const data = await res.json();

      if (!res.ok) {
        if (data.configured === false) {
          setConfigured(false);
          setConnected(false);
          setError("HA not configured");
        } else {
          setError(data.error || "Failed to fetch states");
          setConnected(false);
        }
        return;
      }

      if (Array.isArray(data)) {
        setEntities(data);
        setConnected(true);
        setConfigured(true);
        setError(null);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Network error");
      setConnected(false);
    } finally {
      setLoading(false);
    }
  }, []);

  // ─── Poll for updates ─────────────────────────────────────────

  useEffect(() => {
    refresh();
    intervalRef.current = setInterval(refresh, pollIntervalMs);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [refresh, pollIntervalMs]);

  // ─── Actions ──────────────────────────────────────────────────

  const postAction = useCallback(
    async (body: Record<string, any>) => {
      try {
        const res = await fetch("/api/ha", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Action failed");
        // Refresh states after action
        await refresh();
      } catch (err) {
        setError(err instanceof Error ? err.message : "Action failed");
        throw err;
      }
    },
    [refresh]
  );

  const toggle = useCallback(
    (entityId: string) => postAction({ action: "toggle", entity_id: entityId }),
    [postAction]
  );

  const turnOn = useCallback(
    (entityId: string, data?: Record<string, any>) =>
      postAction({ action: "turn_on", entity_id: entityId, data }),
    [postAction]
  );

  const turnOff = useCallback(
    (entityId: string) => postAction({ action: "turn_off", entity_id: entityId }),
    [postAction]
  );

  const callService = useCallback(
    (domain: string, service: string, data?: Record<string, any>) =>
      postAction({ action: "call_service", domain, service, data }),
    [postAction]
  );

  const setClimate = useCallback(
    (entityId: string, temperature: number, hvacMode?: string) =>
      postAction({ action: "set_climate", entity_id: entityId, data: { temperature, hvac_mode: hvacMode } }),
    [postAction]
  );

  const lock = useCallback(
    (entityId: string) => postAction({ action: "lock", entity_id: entityId }),
    [postAction]
  );

  const unlock = useCallback(
    (entityId: string) => postAction({ action: "unlock", entity_id: entityId }),
    [postAction]
  );

  // ─── Selectors ────────────────────────────────────────────────

  const getEntitiesByDomain = useCallback(
    (domain: string) => entities.filter((e) => e.entity_id.startsWith(`${domain}.`)),
    [entities]
  );

  const getEntitiesByArea = useCallback(
    (area: string) => entities.filter((e) => e.attributes.area_id === area),
    [entities]
  );

  return {
    entities,
    loading,
    connected,
    configured,
    error,
    refresh,
    toggle,
    turnOn,
    turnOff,
    callService,
    setClimate,
    lock,
    unlock,
    getEntitiesByDomain,
    getEntitiesByArea,
  };
}

// ─── Connection Test Hook ────────────────────────────────────────────────────

export function useHAConnection() {
  const [status, setStatus] = useState<"idle" | "testing" | "connected" | "error">("idle");
  const [config, setConfig] = useState<any>(null);

  const testConnection = useCallback(async () => {
    setStatus("testing");
    try {
      const pingRes = await fetch("/api/ha?action=ping");
      const pingData = await pingRes.json();

      if (pingData.connected) {
        const configRes = await fetch("/api/ha?action=config");
        const configData = await configRes.json();
        setConfig(configData);
        setStatus("connected");
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    }
  }, []);

  return { status, config, testConnection };
}
