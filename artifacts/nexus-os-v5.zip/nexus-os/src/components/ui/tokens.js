// ─── Nexus OS Design Tokens ──────────────────────────────────────────────────

export const T = {
  bg: {
    deep: "#08080b",
    base: "#0c0c10",
    card: "rgba(255,255,255,0.02)",
    cardHover: "rgba(255,255,255,0.04)",
    elevated: "rgba(255,255,255,0.06)",
    input: "rgba(255,255,255,0.04)",
  },
  border: {
    subtle: "rgba(255,255,255,0.05)",
    medium: "rgba(255,255,255,0.08)",
    accent: "rgba(96,165,250,0.3)",
  },
  text: {
    primary: "rgba(255,255,255,0.92)",
    secondary: "rgba(255,255,255,0.55)",
    tertiary: "rgba(255,255,255,0.25)",
    muted: "rgba(255,255,255,0.12)",
  },
  accent: {
    blue: "#60A5FA",
    green: "#6EE7B7",
    red: "#F87171",
    yellow: "#FBBF24",
    purple: "#A78BFA",
    cyan: "#67E8F9",
    orange: "#FB923C",
  },
  font: {
    body: "'DM Sans', -apple-system, sans-serif",
    display: "'Outfit', -apple-system, sans-serif",
    mono: "'JetBrains Mono', monospace",
  },
};
