/**
 * Nexus MCP Server — API Route
 * ===============================
 * POST /api/mcp
 *
 * Exposes Nexus capabilities as MCP tools that Home Assistant's
 * Assist voice agent (or any MCP client) can invoke.
 *
 * After deploying, add to HA's configuration.yaml:
 *
 *   rest_command:
 *     nexus_mcp:
 *       url: "http://YOUR_NEXUS_IP:3000/api/mcp"
 *       method: POST
 *       content_type: "application/json"
 *       payload: '{{ payload }}'
 *
 * Or use the HA MCP integration when available.
 *
 * Voice examples:
 *   "Hey Nabu, deploy the latest build"
 *   "Hey Nabu, what's my API spend?"
 *   "Hey Nabu, check GitHub issues"
 *   "Hey Nabu, run the morning briefing"
 */

import { NextRequest } from "next/server";
import { ha } from "@/lib/ha-client";

// ─── Tool Definitions ────────────────────────────────────────────────────────

const NEXUS_TOOLS = [
  {
    name: "nexus_deploy",
    description: "Deploy the latest code to Vercel production.",
    inputSchema: {
      type: "object",
      properties: {
        project: { type: "string", description: "Project name (default: main project)" },
        branch: { type: "string", description: "Branch to deploy (default: main)" },
      },
    },
  },
  {
    name: "nexus_github_status",
    description: "Check GitHub repo status — open issues, PRs, last commit.",
    inputSchema: {
      type: "object",
      properties: {
        repo: { type: "string", description: "Repository name" },
      },
    },
  },
  {
    name: "nexus_system_status",
    description: "Get status of all Nexus services (HA, GitHub, Vercel, Claude API, Ollama, Frigate, MQTT).",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "nexus_morning_briefing",
    description: "Generate a full morning briefing covering security, energy, dev status, ads, and weather.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "nexus_api_usage",
    description: "Check Anthropic API token usage and spend.",
    inputSchema: {
      type: "object",
      properties: {
        period: { type: "string", enum: ["today", "this_week", "this_month"] },
      },
    },
  },
];

// ─── Tool Handlers ───────────────────────────────────────────────────────────

async function handleTool(name: string, args: Record<string, any>): Promise<string> {
  switch (name) {
    case "nexus_deploy": {
      const deployHook = process.env.VERCEL_DEPLOY_HOOK;
      if (deployHook) {
        try {
          const res = await fetch(deployHook, { method: "POST" });
          if (res.ok) {
            return `Deployment triggered. Vercel is building now — should be live in about 90 seconds.`;
          }
          return `Deploy hook returned ${res.status}. Check Vercel dashboard.`;
        } catch (e) {
          return `Deploy failed: ${e instanceof Error ? e.message : String(e)}`;
        }
      }
      return `VERCEL_DEPLOY_HOOK not configured. Add it to .env.local.`;
    }

    case "nexus_github_status": {
      const token = process.env.GITHUB_TOKEN;
      const owner = process.env.GITHUB_OWNER || "rickgriffith";
      const repo = args.repo || "nexus-os";

      if (!token) return "GITHUB_TOKEN not configured.";

      try {
        const headers = { Authorization: `Bearer ${token}`, Accept: "application/vnd.github.v3+json" };
        const [repoInfo, issues, pulls] = await Promise.all([
          fetch(`https://api.github.com/repos/${owner}/${repo}`, { headers }).then((r) => r.json()),
          fetch(`https://api.github.com/repos/${owner}/${repo}/issues?state=open&per_page=5`, { headers }).then((r) => r.json()),
          fetch(`https://api.github.com/repos/${owner}/${repo}/pulls?state=open&per_page=5`, { headers }).then((r) => r.json()),
        ]);

        return `${owner}/${repo}: ${repoInfo.open_issues_count || 0} open issues, ${Array.isArray(pulls) ? pulls.length : 0} open PRs. Last push: ${repoInfo.pushed_at || "unknown"}.`;
      } catch (e) {
        return `GitHub error: ${e instanceof Error ? e.message : String(e)}`;
      }
    }

    case "nexus_system_status": {
      const checks: { name: string; status: string }[] = [];

      // Check HA
      if (ha.isConfigured) {
        const alive = await ha.ping();
        checks.push({ name: "Home Assistant", status: alive ? "online" : "offline" });
      } else {
        checks.push({ name: "Home Assistant", status: "not configured" });
      }

      checks.push({ name: "Claude API", status: process.env.ANTHROPIC_API_KEY ? "configured" : "missing key" });
      checks.push({ name: "GitHub", status: process.env.GITHUB_TOKEN ? "configured" : "missing token" });
      checks.push({ name: "Vercel Deploy", status: process.env.VERCEL_DEPLOY_HOOK ? "configured" : "no hook" });

      return checks.map((c) => `${c.name}: ${c.status}`).join("\n");
    }

    case "nexus_morning_briefing": {
      const parts: string[] = ["Good morning, Rick. Here's your briefing:"];

      // Security from HA
      if (ha.isConfigured) {
        try {
          const locks = await ha.getEntitiesByDomain("lock");
          const allLocked = locks.every((l) => l.state === "locked");
          parts.push(`SECURITY: ${allLocked ? "All doors locked." : "WARNING: Some doors unlocked!"}`);

          const climate = await ha.getEntitiesByDomain("climate");
          if (climate.length > 0) {
            const main = climate[0];
            parts.push(
              `CLIMATE: ${main.attributes.current_temperature}°F inside, AC set to ${main.attributes.temperature}°F (${main.state}).`
            );
          }
        } catch {
          parts.push("SECURITY: Could not reach HA.");
        }
      }

      parts.push("DEV: Check GitHub and Vercel dashboard for latest status.");
      return parts.join("\n\n");
    }

    case "nexus_api_usage": {
      return `API usage tracking not yet connected to Anthropic usage API. Check console.anthropic.com for current spend.`;
    }

    default:
      return `Unknown tool: ${name}`;
  }
}

// ─── MCP Protocol Handler ────────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // MCP protocol: tools/list
    if (body.method === "tools/list") {
      return Response.json({
        tools: NEXUS_TOOLS,
      });
    }

    // MCP protocol: tools/call
    if (body.method === "tools/call") {
      const { name, arguments: args } = body.params || {};
      if (!name) {
        return Response.json({ error: "Missing tool name" }, { status: 400 });
      }
      const result = await handleTool(name, args || {});
      return Response.json({
        content: [{ type: "text", text: result }],
      });
    }

    // Simple direct call (non-MCP clients)
    if (body.tool && body.args) {
      const result = await handleTool(body.tool, body.args);
      return Response.json({ result });
    }

    return Response.json({ error: "Invalid request. Use MCP protocol or {tool, args}." }, { status: 400 });
  } catch (error) {
    console.error("MCP error:", error);
    return Response.json(
      { error: error instanceof Error ? error.message : "Internal server error" },
      { status: 500 }
    );
  }
}

// Health check
export async function GET() {
  return Response.json({
    name: "nexus-mcp",
    version: "1.0.0",
    status: "online",
    tools: NEXUS_TOOLS.length,
    description: "Nexus OS MCP Server — deploy code, check GitHub, system status, morning briefings",
  });
}
