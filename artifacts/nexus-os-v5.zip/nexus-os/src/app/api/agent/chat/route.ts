/**
 * Agent Bay → Home Assistant API Route
 * ======================================
 * POST /api/agent/chat
 *
 * Sends user message to Claude with HA tool definitions.
 * Claude decides which tools to call, we execute them against
 * the live HA instance, feed results back, and return the response.
 *
 * This is the agentic loop: user → Claude → HA → Claude → user.
 */

import { NextRequest } from "next/server";
import { ha, type HAEntity } from "@/lib/ha-client";

// ─── Claude Tool Definitions for HA ─────────────────────────────────────────

const HA_TOOLS = [
  {
    name: "ha_get_states",
    description:
      "Get the current state of all Home Assistant entities, or filter by domain (light, switch, climate, lock, sensor, fan, cover, media_player, binary_sensor, automation).",
    input_schema: {
      type: "object" as const,
      properties: {
        domain: {
          type: "string",
          description: "Filter by domain. Omit for all entities.",
        },
      },
    },
  },
  {
    name: "ha_get_entity",
    description: "Get the detailed state and attributes of a specific entity by entity_id.",
    input_schema: {
      type: "object" as const,
      properties: {
        entity_id: {
          type: "string",
          description: "The entity_id (e.g. light.living_room, climate.main_floor)",
        },
      },
      required: ["entity_id"],
    },
  },
  {
    name: "ha_call_service",
    description:
      "Call any Home Assistant service. Common examples: light/turn_on, light/turn_off, lock/lock, lock/unlock, climate/set_temperature, fan/turn_on, switch/toggle, scene/turn_on, automation/trigger.",
    input_schema: {
      type: "object" as const,
      properties: {
        domain: { type: "string", description: "Service domain (e.g. light, lock, climate)" },
        service: { type: "string", description: "Service name (e.g. turn_on, turn_off, lock, set_temperature)" },
        data: {
          type: "object",
          description:
            "Service data. Always include entity_id. For lights: brightness (0-255), color_temp, rgb_color. For climate: temperature, hvac_mode. For fans: percentage.",
        },
      },
      required: ["domain", "service"],
    },
  },
  {
    name: "ha_get_history",
    description: "Get state change history for an entity over the last 24 hours.",
    input_schema: {
      type: "object" as const,
      properties: {
        entity_id: { type: "string", description: "The entity_id to get history for" },
      },
      required: ["entity_id"],
    },
  },
  {
    name: "ha_fire_event",
    description: "Fire a custom event on the HA event bus.",
    input_schema: {
      type: "object" as const,
      properties: {
        event_type: { type: "string", description: "Event type name" },
        event_data: { type: "object", description: "Event payload data" },
      },
      required: ["event_type"],
    },
  },
];

// ─── Tool Executor ───────────────────────────────────────────────────────────

async function executeTool(name: string, input: Record<string, any>): Promise<string> {
  try {
    switch (name) {
      case "ha_get_states": {
        let states: HAEntity[];
        if (input.domain) {
          states = await ha.getEntitiesByDomain(input.domain);
        } else {
          states = await ha.getStates();
        }
        // Summarize for Claude — full payload is too large
        const summary = states.map((s) => ({
          id: s.entity_id,
          state: s.state,
          name: s.attributes.friendly_name || s.entity_id,
          ...(s.attributes.brightness !== undefined && { brightness: s.attributes.brightness }),
          ...(s.attributes.temperature !== undefined && { temperature: s.attributes.temperature }),
          ...(s.attributes.current_temperature !== undefined && { current_temp: s.attributes.current_temperature }),
          ...(s.attributes.hvac_action && { hvac_action: s.attributes.hvac_action }),
          ...(s.attributes.percentage !== undefined && { percentage: s.attributes.percentage }),
        }));
        return JSON.stringify(summary, null, 2);
      }

      case "ha_get_entity": {
        const entity = await ha.getState(input.entity_id);
        return JSON.stringify(entity, null, 2);
      }

      case "ha_call_service": {
        const result = await ha.callService(input.domain, input.service, input.data);
        return `Service ${input.domain}.${input.service} called successfully. ${result.length} entities affected.`;
      }

      case "ha_get_history": {
        const history = await ha.getHistory(input.entity_id);
        // Summarize recent state changes
        const changes = (history[0] || []).slice(-10).map((s) => ({
          state: s.state,
          when: s.last_changed,
        }));
        return JSON.stringify(changes, null, 2);
      }

      case "ha_fire_event": {
        const result = await ha.fireEvent(input.event_type, input.event_data);
        return `Event '${input.event_type}' fired. ${result.message}`;
      }

      default:
        return `Unknown tool: ${name}`;
    }
  } catch (error) {
    return `Error executing ${name}: ${error instanceof Error ? error.message : String(error)}`;
  }
}

// ─── Build System Prompt with Live State ─────────────────────────────────────

async function buildSystemPrompt(): Promise<string> {
  try {
    const [config, states] = await Promise.all([ha.getConfig(), ha.getStates()]);

    const domainCounts: Record<string, number> = {};
    states.forEach((s) => {
      const domain = s.entity_id.split(".")[0];
      domainCounts[domain] = (domainCounts[domain] || 0) + 1;
    });

    const entitySummary = Object.entries(domainCounts)
      .map(([domain, count]) => `  ${domain}: ${count}`)
      .join("\n");

    return `You are the Nexus AI assistant — Rick's personal home + dev operations agent.
You control Home Assistant devices, monitor energy, check cameras, and manage the Nexus ecosystem.

HOME ASSISTANT STATUS:
- Location: ${config.location_name}
- Version: ${config.version}
- Total entities: ${states.length}
- Breakdown:
${entitySummary}

RULES:
- Always use entity_id (e.g. light.living_room) in tool calls, not friendly names
- Confirm before unlocking doors or disarming security
- For lights, brightness is 0-255
- Be concise and direct — Rick doesn't want fluff
- You can read states, control devices, check history, and fire events
- If something fails, say what happened and suggest a fix
- For cameras, note that Frigate handles AI detection — you can check sensor states`;
  } catch {
    return `You are the Nexus AI assistant. Home Assistant connection is not available right now. Help with what you can and suggest the user check System settings to configure HA.`;
  }
}

// ─── Main Handler ────────────────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { messages } = body;

    const anthropicKey = process.env.ANTHROPIC_API_KEY;
    if (!anthropicKey) {
      return Response.json({ error: "ANTHROPIC_API_KEY not configured" }, { status: 500 });
    }

    const systemPrompt = await buildSystemPrompt();

    // Claude API request with tools
    let claudeMessages = messages.map((m: any) => ({
      role: m.role,
      content: m.content,
    }));

    let allToolCalls: any[] = [];
    let iterations = 0;
    const MAX_ITERATIONS = 5;

    // Agentic loop — Claude may call multiple tools
    let response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": anthropicKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1024,
        system: systemPrompt,
        tools: HA_TOOLS,
        messages: claudeMessages,
      }),
    });

    let result = await response.json();

    // Process tool calls in a loop
    while (result.stop_reason === "tool_use" && iterations < MAX_ITERATIONS) {
      const toolUseBlocks = (result.content || []).filter((b: any) => b.type === "tool_use");
      const toolResults: any[] = [];

      for (const toolCall of toolUseBlocks) {
        const toolResult = await executeTool(toolCall.name, toolCall.input);
        allToolCalls.push({
          name: toolCall.name,
          input: toolCall.input,
          result: toolResult,
        });
        toolResults.push({
          type: "tool_result",
          tool_use_id: toolCall.id,
          content: toolResult,
        });
      }

      // Feed tool results back to Claude
      claudeMessages = [
        ...claudeMessages,
        { role: "assistant" as const, content: result.content },
        { role: "user" as const, content: toolResults },
      ];

      response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": anthropicKey,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1024,
          system: systemPrompt,
          tools: HA_TOOLS,
          messages: claudeMessages,
        }),
      });

      result = await response.json();
      iterations++;
    }

    // Extract final text
    const textBlocks = (result.content || []).filter((b: any) => b.type === "text");
    const finalText = textBlocks.map((b: any) => b.text).join("\n");

    return Response.json({
      response: finalText,
      tool_calls: allToolCalls,
      model: result.model,
      usage: result.usage,
    });
  } catch (error) {
    console.error("Agent chat error:", error);
    return Response.json(
      { error: error instanceof Error ? error.message : "Internal server error" },
      { status: 500 }
    );
  }
}
