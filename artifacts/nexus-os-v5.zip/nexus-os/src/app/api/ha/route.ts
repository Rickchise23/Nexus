/**
 * /api/ha/route.ts — Home Assistant API Proxy
 * =============================================
 * All HA communication goes through here so the HA token
 * never leaves the server. The frontend calls these endpoints.
 *
 * GET  /api/ha?action=ping          → health check
 * GET  /api/ha?action=config        → HA config
 * GET  /api/ha?action=states        → all entity states
 * GET  /api/ha?action=state&id=...  → single entity state
 * GET  /api/ha?action=services      → available services
 * GET  /api/ha?action=history&id=.. → entity history
 * GET  /api/ha?action=logbook       → logbook entries
 * POST /api/ha                      → call service / toggle / set
 */

import { NextRequest } from "next/server";
import { ha } from "@/lib/ha-client";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const action = searchParams.get("action");

  try {
    if (!ha.isConfigured) {
      return Response.json(
        { error: "Home Assistant not configured", configured: false },
        { status: 503 }
      );
    }

    switch (action) {
      case "ping": {
        const alive = await ha.ping();
        return Response.json({ connected: alive });
      }

      case "config": {
        const config = await ha.getConfig();
        return Response.json(config);
      }

      case "states": {
        const states = await ha.getStates();
        return Response.json(states);
      }

      case "state": {
        const id = searchParams.get("id");
        if (!id) return Response.json({ error: "Missing id" }, { status: 400 });
        const state = await ha.getState(id);
        return Response.json(state);
      }

      case "services": {
        const services = await ha.getServices();
        return Response.json(services);
      }

      case "history": {
        const entityId = searchParams.get("id") || undefined;
        const start = searchParams.get("start") || undefined;
        const end = searchParams.get("end") || undefined;
        const history = await ha.getHistory(entityId, start, end);
        return Response.json(history);
      }

      case "logbook": {
        const entityId = searchParams.get("id") || undefined;
        const start = searchParams.get("start") || undefined;
        const logbook = await ha.getLogbook(start, entityId);
        return Response.json(logbook);
      }

      default:
        return Response.json({ error: `Unknown action: ${action}` }, { status: 400 });
    }
  } catch (error) {
    console.error("HA API error:", error);
    return Response.json(
      { error: error instanceof Error ? error.message : "HA request failed" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    if (!ha.isConfigured) {
      return Response.json({ error: "Home Assistant not configured" }, { status: 503 });
    }

    const body = await req.json();
    const { action, entity_id, domain, service, data } = body;

    switch (action) {
      case "call_service": {
        if (!domain || !service) {
          return Response.json({ error: "Missing domain or service" }, { status: 400 });
        }
        const result = await ha.callService(domain, service, data);
        return Response.json({ success: true, result });
      }

      case "toggle": {
        if (!entity_id) return Response.json({ error: "Missing entity_id" }, { status: 400 });
        const result = await ha.toggle(entity_id);
        return Response.json({ success: true, result });
      }

      case "turn_on": {
        if (!entity_id) return Response.json({ error: "Missing entity_id" }, { status: 400 });
        const result = await ha.turnOn(entity_id, data);
        return Response.json({ success: true, result });
      }

      case "turn_off": {
        if (!entity_id) return Response.json({ error: "Missing entity_id" }, { status: 400 });
        const result = await ha.turnOff(entity_id);
        return Response.json({ success: true, result });
      }

      case "set_climate": {
        if (!entity_id || !data?.temperature) {
          return Response.json({ error: "Missing entity_id or temperature" }, { status: 400 });
        }
        const result = await ha.setClimate(entity_id, data.temperature, data.hvac_mode);
        return Response.json({ success: true, result });
      }

      case "lock": {
        if (!entity_id) return Response.json({ error: "Missing entity_id" }, { status: 400 });
        const result = await ha.lockEntity(entity_id);
        return Response.json({ success: true, result });
      }

      case "unlock": {
        if (!entity_id) return Response.json({ error: "Missing entity_id" }, { status: 400 });
        const result = await ha.unlockEntity(entity_id);
        return Response.json({ success: true, result });
      }

      case "fire_event": {
        const { event_type, event_data } = body;
        if (!event_type) return Response.json({ error: "Missing event_type" }, { status: 400 });
        const result = await ha.fireEvent(event_type, event_data);
        return Response.json({ success: true, result });
      }

      default:
        return Response.json({ error: `Unknown action: ${action}` }, { status: 400 });
    }
  } catch (error) {
    console.error("HA POST error:", error);
    return Response.json(
      { error: error instanceof Error ? error.message : "HA request failed" },
      { status: 500 }
    );
  }
}
