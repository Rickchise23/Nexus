/**
 * /api/ha/stream/route.ts — Real-time HA State Stream
 * =====================================================
 * GET /api/ha/stream
 *
 * Server-Sent Events (SSE) endpoint that streams HA state changes
 * to the browser in real-time. The frontend subscribes with EventSource.
 *
 * This replaces the 5-second polling in useHA with instant updates.
 *
 * Architecture:
 *   Browser ←SSE← Next.js API ←poll← HA REST API
 *
 * We poll HA every 2 seconds server-side and only push diffs to the
 * browser. This is a stepping stone — full WebSocket from HA would
 * eliminate the server-side poll too, but requires a persistent
 * connection that's tricky on Vercel's serverless. For local dev
 * on the Mac Mini this works perfectly.
 *
 * Usage in browser:
 *   const source = new EventSource("/api/ha/stream");
 *   source.onmessage = (e) => {
 *     const { entities, changed } = JSON.parse(e.data);
 *     // entities = full state array
 *     // changed = array of entity_ids that changed since last push
 *   };
 */

import { NextRequest } from "next/server";
import { ha } from "@/lib/ha-client";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  if (!ha.isConfigured) {
    return new Response(JSON.stringify({ error: "HA not configured" }), {
      status: 503,
      headers: { "Content-Type": "application/json" },
    });
  }

  const encoder = new TextEncoder();
  let lastStates: Record<string, string> = {};
  let alive = true;

  const stream = new ReadableStream({
    async start(controller) {
      const push = (data: any) => {
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
        } catch {
          alive = false;
        }
      };

      // Initial full state push
      try {
        const states = await ha.getStates();
        const entities = states.map((s) => ({
          entity_id: s.entity_id,
          state: s.state,
          attributes: s.attributes,
          last_changed: s.last_changed,
        }));

        lastStates = {};
        states.forEach((s) => {
          lastStates[s.entity_id] = `${s.state}|${s.last_updated}`;
        });

        push({ type: "full", entities, count: entities.length });
      } catch (err) {
        push({ type: "error", message: err instanceof Error ? err.message : "Initial fetch failed" });
        controller.close();
        return;
      }

      // Poll for changes every 2 seconds
      const interval = setInterval(async () => {
        if (!alive) {
          clearInterval(interval);
          try { controller.close(); } catch {}
          return;
        }

        try {
          const states = await ha.getStates();
          const changed: string[] = [];

          states.forEach((s) => {
            const key = `${s.state}|${s.last_updated}`;
            if (lastStates[s.entity_id] !== key) {
              changed.push(s.entity_id);
              lastStates[s.entity_id] = key;
            }
          });

          if (changed.length > 0) {
            const changedEntities = states
              .filter((s) => changed.includes(s.entity_id))
              .map((s) => ({
                entity_id: s.entity_id,
                state: s.state,
                attributes: s.attributes,
                last_changed: s.last_changed,
              }));

            push({ type: "diff", entities: changedEntities, changed });
          } else {
            // Heartbeat every cycle to keep connection alive
            push({ type: "heartbeat", ts: Date.now() });
          }
        } catch (err) {
          push({ type: "error", message: err instanceof Error ? err.message : "Poll failed" });
        }
      }, 2000);

      // Clean up on abort
      req.signal.addEventListener("abort", () => {
        alive = false;
        clearInterval(interval);
        try { controller.close(); } catch {}
      });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
