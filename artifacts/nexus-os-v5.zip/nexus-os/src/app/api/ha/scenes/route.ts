/**
 * /api/ha/scenes/route.ts — HA Scenes & Scripts
 * ================================================
 * GET  /api/ha/scenes   → list all scenes and scripts
 * POST /api/ha/scenes   → activate a scene or run a script
 */

import { NextRequest } from "next/server";
import { ha } from "@/lib/ha-client";

export async function GET(req: NextRequest) {
  if (!ha.isConfigured) {
    return Response.json({ configured: false });
  }

  try {
    const states = await ha.getStates();

    const scenes = states
      .filter((s) => s.entity_id.startsWith("scene."))
      .map((s) => ({
        entity_id: s.entity_id,
        name: s.attributes.friendly_name || s.entity_id.replace("scene.", "").replace(/_/g, " "),
        id: s.entity_id.replace("scene.", ""),
      }));

    const scripts = states
      .filter((s) => s.entity_id.startsWith("script."))
      .map((s) => ({
        entity_id: s.entity_id,
        name: s.attributes.friendly_name || s.entity_id.replace("script.", "").replace(/_/g, " "),
        id: s.entity_id.replace("script.", ""),
        state: s.state,
      }));

    return Response.json({ configured: true, scenes, scripts });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Failed" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  if (!ha.isConfigured) {
    return Response.json({ error: "HA not configured" }, { status: 503 });
  }

  try {
    const body = await req.json();
    const { entity_id } = body;

    if (!entity_id) {
      return Response.json({ error: "Missing entity_id" }, { status: 400 });
    }

    if (entity_id.startsWith("scene.")) {
      await ha.callService("scene", "turn_on", { entity_id });
    } else if (entity_id.startsWith("script.")) {
      await ha.callService("script", "turn_on", { entity_id });
    } else {
      return Response.json({ error: "Must be scene.* or script.*" }, { status: 400 });
    }

    return Response.json({ success: true, activated: entity_id });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Failed" },
      { status: 500 }
    );
  }
}
