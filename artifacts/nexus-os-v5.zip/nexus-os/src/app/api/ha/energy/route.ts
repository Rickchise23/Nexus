/**
 * /api/ha/energy/route.ts — Energy Data from HA
 * ================================================
 * GET /api/ha/energy
 *
 * Pulls energy-related entities from HA and formats them
 * for the Energy Dashboard module. Falls back to mock data
 * when HA isn't connected or has no energy sensors.
 */

import { NextRequest } from "next/server";
import { ha } from "@/lib/ha-client";

export async function GET(req: NextRequest) {
  if (!ha.isConfigured) {
    return Response.json({ configured: false, source: "mock" });
  }

  try {
    const states = await ha.getStates();

    // Find energy-related entities
    const energyEntities = states.filter((s) => {
      const dc = s.attributes.device_class;
      const unit = s.attributes.unit_of_measurement;
      return (
        dc === "energy" ||
        dc === "power" ||
        dc === "voltage" ||
        dc === "current" ||
        unit === "kWh" ||
        unit === "W" ||
        unit === "Wh" ||
        s.entity_id.includes("energy") ||
        s.entity_id.includes("power") ||
        s.entity_id.includes("solar") ||
        s.entity_id.includes("battery")
      );
    });

    // Categorize
    const consumption = energyEntities.filter(
      (e) =>
        e.attributes.device_class === "energy" &&
        !e.entity_id.includes("solar") &&
        !e.entity_id.includes("production") &&
        !e.entity_id.includes("export")
    );

    const solar = energyEntities.filter(
      (e) =>
        e.entity_id.includes("solar") || e.entity_id.includes("production")
    );

    const battery = energyEntities.filter(
      (e) =>
        e.entity_id.includes("battery") && e.attributes.device_class !== "battery"
    );

    const power = energyEntities.filter(
      (e) => e.attributes.device_class === "power" || e.attributes.unit_of_measurement === "W"
    );

    // Also get climate entities for HVAC consumption estimate
    const climate = states.filter((s) => s.entity_id.startsWith("climate."));

    // Get history for the main energy sensor (last 24h) if available
    let history = null;
    const mainEnergySensor = consumption[0] || energyEntities[0];
    if (mainEnergySensor) {
      try {
        const startTime = new Date(Date.now() - 86400000).toISOString();
        const historyData = await ha.getHistory(mainEnergySensor.entity_id, startTime);
        if (historyData[0]) {
          history = historyData[0].map((h) => ({
            time: h.last_changed,
            value: parseFloat(h.state) || 0,
          }));
        }
      } catch {}
    }

    return Response.json({
      configured: true,
      source: "live",
      summary: {
        total_entities: energyEntities.length,
        consumption_sensors: consumption.length,
        solar_sensors: solar.length,
        battery_sensors: battery.length,
        power_sensors: power.length,
        climate_entities: climate.length,
      },
      entities: {
        consumption: consumption.map((e) => ({
          entity_id: e.entity_id,
          name: e.attributes.friendly_name,
          state: parseFloat(e.state) || 0,
          unit: e.attributes.unit_of_measurement,
        })),
        solar: solar.map((e) => ({
          entity_id: e.entity_id,
          name: e.attributes.friendly_name,
          state: parseFloat(e.state) || 0,
          unit: e.attributes.unit_of_measurement,
        })),
        battery: battery.map((e) => ({
          entity_id: e.entity_id,
          name: e.attributes.friendly_name,
          state: parseFloat(e.state) || 0,
          unit: e.attributes.unit_of_measurement,
        })),
        power: power.map((e) => ({
          entity_id: e.entity_id,
          name: e.attributes.friendly_name,
          state: parseFloat(e.state) || 0,
          unit: e.attributes.unit_of_measurement,
        })),
        climate: climate.map((e) => ({
          entity_id: e.entity_id,
          name: e.attributes.friendly_name,
          state: e.state,
          current_temp: e.attributes.current_temperature,
          target_temp: e.attributes.temperature,
          hvac_action: e.attributes.hvac_action,
        })),
      },
      history,
    });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Energy fetch failed" },
      { status: 500 }
    );
  }
}
