/**
 * /api/ha/health/route.ts — System Health Check
 * ================================================
 * GET /api/ha/health
 *
 * Checks all Nexus services in parallel and returns status.
 * Used by the System module to show real service health.
 */

import { NextRequest } from "next/server";
import { ha } from "@/lib/ha-client";

interface ServiceCheck {
  name: string;
  status: "online" | "offline" | "unconfigured";
  detail: string;
  latency?: number;
}

export async function GET(req: NextRequest) {
  const checks: ServiceCheck[] = [];
  const start = Date.now();

  // ─── Home Assistant ────────────────────────────────────────
  if (ha.isConfigured) {
    try {
      const t0 = Date.now();
      const alive = await ha.ping();
      const latency = Date.now() - t0;

      if (alive) {
        const config = await ha.getConfig();
        const states = await ha.getStates();
        checks.push({
          name: "Home Assistant",
          status: "online",
          detail: `v${config.version} — ${config.location_name} — ${states.length} entities`,
          latency,
        });
      } else {
        checks.push({ name: "Home Assistant", status: "offline", detail: "Ping failed" });
      }
    } catch (e) {
      checks.push({
        name: "Home Assistant",
        status: "offline",
        detail: e instanceof Error ? e.message : "Connection failed",
      });
    }
  } else {
    checks.push({ name: "Home Assistant", status: "unconfigured", detail: "Set HA_URL and HA_TOKEN in .env.local" });
  }

  // ─── Claude API ────────────────────────────────────────────
  if (process.env.ANTHROPIC_API_KEY) {
    checks.push({ name: "Claude API", status: "online", detail: "API key configured — Agent Bay ready" });
  } else {
    checks.push({ name: "Claude API", status: "unconfigured", detail: "Set ANTHROPIC_API_KEY in .env.local" });
  }

  // ─── GitHub ────────────────────────────────────────────────
  if (process.env.GITHUB_TOKEN) {
    try {
      const t0 = Date.now();
      const res = await fetch("https://api.github.com/user", {
        headers: { Authorization: `Bearer ${process.env.GITHUB_TOKEN}` },
      });
      const latency = Date.now() - t0;
      if (res.ok) {
        const user = await res.json();
        checks.push({ name: "GitHub", status: "online", detail: `${user.login} — token valid`, latency });
      } else {
        checks.push({ name: "GitHub", status: "offline", detail: `Token invalid (${res.status})` });
      }
    } catch {
      checks.push({ name: "GitHub", status: "offline", detail: "Could not reach GitHub API" });
    }
  } else {
    checks.push({ name: "GitHub", status: "unconfigured", detail: "Set GITHUB_TOKEN in .env.local" });
  }

  // ─── Vercel Deploy Hook ────────────────────────────────────
  if (process.env.VERCEL_DEPLOY_HOOK) {
    checks.push({ name: "Vercel Deploy", status: "online", detail: "Deploy hook configured" });
  } else {
    checks.push({ name: "Vercel Deploy", status: "unconfigured", detail: "Set VERCEL_DEPLOY_HOOK in .env.local" });
  }

  // ─── Frigate ───────────────────────────────────────────────
  const frigateUrl = process.env.FRIGATE_URL;
  if (frigateUrl) {
    try {
      const t0 = Date.now();
      const res = await fetch(`${frigateUrl}/api/version`, { signal: AbortSignal.timeout(3000) });
      const latency = Date.now() - t0;
      if (res.ok) {
        const version = await res.text();
        checks.push({ name: "Frigate NVR", status: "online", detail: `v${version.trim()}`, latency });
      } else {
        checks.push({ name: "Frigate NVR", status: "offline", detail: `HTTP ${res.status}` });
      }
    } catch {
      checks.push({ name: "Frigate NVR", status: "offline", detail: "Cannot reach Frigate" });
    }
  } else {
    checks.push({ name: "Frigate NVR", status: "unconfigured", detail: "Set FRIGATE_URL in .env.local" });
  }

  // ─── MQTT ──────────────────────────────────────────────────
  if (process.env.MQTT_URL) {
    checks.push({ name: "MQTT Broker", status: "online", detail: "URL configured" });
  } else {
    checks.push({ name: "MQTT Broker", status: "unconfigured", detail: "Set MQTT_URL in .env.local" });
  }

  const totalLatency = Date.now() - start;

  return Response.json({
    status: checks.every((c) => c.status !== "offline") ? "healthy" : "degraded",
    services: checks,
    checked_at: new Date().toISOString(),
    total_latency_ms: totalLatency,
  });
}
