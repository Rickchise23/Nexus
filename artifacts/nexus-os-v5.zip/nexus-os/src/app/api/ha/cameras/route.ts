/**
 * /api/ha/cameras/route.ts — Frigate Camera Proxy
 * ==================================================
 * GET /api/ha/cameras?action=stats     → camera stats
 * GET /api/ha/cameras?action=events    → recent events
 * GET /api/ha/cameras?action=snapshot&camera=front_yard → latest snapshot
 */

import { NextRequest } from "next/server";
import { frigate } from "@/lib/frigate-client";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const action = searchParams.get("action");

  try {
    if (!frigate.isConfigured) {
      return Response.json(
        { error: "Frigate not configured", configured: false },
        { status: 503 }
      );
    }

    switch (action) {
      case "stats": {
        const stats = await frigate.getStats();
        return Response.json(stats);
      }

      case "events": {
        const camera = searchParams.get("camera") || undefined;
        const label = searchParams.get("label") || undefined;
        const limit = parseInt(searchParams.get("limit") || "20");
        const events = await frigate.getEvents({ camera, label, limit });
        return Response.json(events);
      }

      case "cameras": {
        const cameras = await frigate.getCameras();
        return Response.json(cameras);
      }

      case "snapshot": {
        const camera = searchParams.get("camera");
        if (!camera) return Response.json({ error: "Missing camera" }, { status: 400 });
        // Proxy the snapshot image
        const url = frigate.getSnapshotUrl(camera);
        const imgRes = await fetch(url, { signal: AbortSignal.timeout(5000) });
        if (!imgRes.ok) return Response.json({ error: "Snapshot failed" }, { status: 502 });
        const blob = await imgRes.blob();
        return new Response(blob, {
          headers: {
            "Content-Type": imgRes.headers.get("content-type") || "image/jpeg",
            "Cache-Control": "no-cache",
          },
        });
      }

      case "event_snapshot": {
        const eventId = searchParams.get("event_id");
        if (!eventId) return Response.json({ error: "Missing event_id" }, { status: 400 });
        const url = frigate.getEventSnapshotUrl(eventId);
        const imgRes = await fetch(url, { signal: AbortSignal.timeout(5000) });
        if (!imgRes.ok) return Response.json({ error: "Event snapshot failed" }, { status: 502 });
        const blob = await imgRes.blob();
        return new Response(blob, {
          headers: {
            "Content-Type": "image/jpeg",
            "Cache-Control": "no-cache",
          },
        });
      }

      default:
        return Response.json({ error: `Unknown action: ${action}` }, { status: 400 });
    }
  } catch (error) {
    console.error("Cameras API error:", error);
    return Response.json(
      { error: error instanceof Error ? error.message : "Camera request failed" },
      { status: 500 }
    );
  }
}
