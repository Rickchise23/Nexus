/**
 * /api/ha/automations/route.ts — HA Automations
 * =================================================
 * GET  /api/ha/automations              → list all automations
 * POST /api/ha/automations              → toggle/trigger automations
 */

import { NextRequest } from "next/server";
import { ha } from "@/lib/ha-client";

export async function GET(req: NextRequest) {
  if (!ha.isConfigured) {
    return Response.json({ configured: false });
  }

  try {
    const states = await ha.getStates();
    const automations = states
      .filter((s) => s.entity_id.startsWith("automation."))
      .map((s) => ({
        entity_id: s.entity_id,
        alias: s.attributes.friendly_name || s.entity_id.replace("automation.", ""),
        state: s.state, // "on" or "off"
        last_triggered: s.attributes.last_triggered || null,
        current: s.attributes.current || 0,
        id: s.attributes.id || s.entity_id,
      }));

    return Response.json({ configured: true, automations });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Failed" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  if (!ha.isConfigured) {
    return Response.json({ error: "HA not configured" }, { status: 503 });
  }

  try {
    const body = await req.json();
    const { action, entity_id } = body;

    switch (action) {
      case "toggle": {
        await ha.callService("automation", "toggle", { entity_id });
        return Response.json({ success: true });
      }
      case "trigger": {
        await ha.callService("automation", "trigger", { entity_id });
        return Response.json({ success: true });
      }
      case "turn_on": {
        await ha.callService("automation", "turn_on", { entity_id });
        return Response.json({ success: true });
      }
      case "turn_off": {
        await ha.callService("automation", "turn_off", { entity_id });
        return Response.json({ success: true });
      }
      default:
        return Response.json({ error: `Unknown action: ${action}` }, { status: 400 });
    }
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Failed" },
      { status: 500 }
    );
  }
}
