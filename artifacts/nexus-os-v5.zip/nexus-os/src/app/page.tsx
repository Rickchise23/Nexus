"use client";

import dynamic from "next/dynamic";

// Dynamic import to avoid SSR issues with recharts/lucide
const NexusOS = dynamic(() => import("@/components/NexusOS"), {
  ssr: false,
  loading: () => (
    <div className="h-screen flex items-center justify-center" style={{ background: "#08080b" }}>
      <div className="text-center">
        <div className="text-sm tracking-[0.25em] font-extralight mb-3" style={{ fontFamily: "Outfit, sans-serif", color: "rgba(255,255,255,0.92)" }}>
          NEXUS
        </div>
        <div className="flex gap-1 justify-center">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-1.5 h-1.5 rounded-full"
              style={{
                background: "#60A5FA",
                animation: `pulse 1.4s ease-in-out ${i * 0.2}s infinite`,
              }}
            />
          ))}
        </div>
      </div>
      <style>{`@keyframes pulse { 0%, 100% { opacity: 0.3; } 50% { opacity: 1; } }`}</style>
    </div>
  ),
});

export default function Page() {
  return <NexusOS />;
}
