/**
 * Home Assistant REST API Client
 * ================================
 * Server-side only — reads HA_URL and HA_TOKEN from env.
 *
 * Usage in API routes:
 *   import { ha } from "@/lib/ha-client";
 *   const states = await ha.getStates();
 *   await ha.callService("light", "turn_on", { entity_id: "light.living_room" });
 */

// ─── Types ───────────────────────────────────────────────────────────────────

export interface HAEntity {
  entity_id: string;
  state: string;
  attributes: Record<string, any>;
  last_changed: string;
  last_updated: string;
  context: { id: string; parent_id: string | null; user_id: string | null };
}

export interface HAConfig {
  location_name: string;
  latitude: number;
  longitude: number;
  elevation: number;
  unit_system: Record<string, string>;
  time_zone: string;
  version: string;
  state: string;
}

export interface HAService {
  domain: string;
  services: Record<string, { name: string; description: string; fields: Record<string, any> }>;
}

export interface HAEvent {
  event_type: string;
  listener_count: number;
}

export interface HALogbookEntry {
  when: string;
  name: string;
  message: string;
  entity_id?: string;
  domain?: string;
}

// ─── Client ──────────────────────────────────────────────────────────────────

class HomeAssistantClient {
  private url: string;
  private token: string;

  constructor() {
    this.url = process.env.HA_URL || "";
    this.token = process.env.HA_TOKEN || "";
  }

  get isConfigured(): boolean {
    return Boolean(this.url && this.token);
  }

  private get headers(): Record<string, string> {
    return {
      Authorization: `Bearer ${this.token}`,
      "Content-Type": "application/json",
    };
  }

  private async request<T>(path: string, options: RequestInit = {}): Promise<T> {
    if (!this.isConfigured) {
      throw new Error("Home Assistant not configured. Set HA_URL and HA_TOKEN in .env.local");
    }

    const res = await fetch(`${this.url}/api${path}`, {
      ...options,
      headers: { ...this.headers, ...options.headers },
    });

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`HA API error ${res.status}: ${res.statusText} — ${body}`);
    }

    return res.json();
  }

  // ─── Health ──────────────────────────────────────────────────────

  async ping(): Promise<boolean> {
    try {
      const data = await this.request<{ message: string }>("/");
      return data.message === "API running.";
    } catch {
      return false;
    }
  }

  // ─── Config ──────────────────────────────────────────────────────

  async getConfig(): Promise<HAConfig> {
    return this.request<HAConfig>("/config");
  }

  // ─── States ──────────────────────────────────────────────────────

  async getStates(): Promise<HAEntity[]> {
    return this.request<HAEntity[]>("/states");
  }

  async getState(entityId: string): Promise<HAEntity> {
    return this.request<HAEntity>(`/states/${entityId}`);
  }

  async setState(entityId: string, state: string, attributes?: Record<string, any>): Promise<HAEntity> {
    return this.request<HAEntity>(`/states/${entityId}`, {
      method: "POST",
      body: JSON.stringify({ state, attributes }),
    });
  }

  // ─── Services ────────────────────────────────────────────────────

  async getServices(): Promise<HAService[]> {
    return this.request<HAService[]>("/services");
  }

  async callService(domain: string, service: string, data?: Record<string, any>): Promise<HAEntity[]> {
    return this.request<HAEntity[]>(`/services/${domain}/${service}`, {
      method: "POST",
      body: JSON.stringify(data || {}),
    });
  }

  // ─── Events ──────────────────────────────────────────────────────

  async getEvents(): Promise<HAEvent[]> {
    return this.request<HAEvent[]>("/events");
  }

  async fireEvent(eventType: string, data?: Record<string, any>): Promise<{ message: string }> {
    return this.request<{ message: string }>(`/events/${eventType}`, {
      method: "POST",
      body: JSON.stringify(data || {}),
    });
  }

  // ─── History ─────────────────────────────────────────────────────

  async getHistory(
    entityId?: string,
    startTime?: string,
    endTime?: string
  ): Promise<HAEntity[][]> {
    const params = new URLSearchParams();
    if (entityId) params.set("filter_entity_id", entityId);
    if (endTime) params.set("end_time", endTime);

    const timestamp = startTime || new Date(Date.now() - 86400000).toISOString();
    const qs = params.toString();
    return this.request<HAEntity[][]>(`/history/period/${timestamp}${qs ? "?" + qs : ""}`);
  }

  // ─── Logbook ─────────────────────────────────────────────────────

  async getLogbook(startTime?: string, entityId?: string): Promise<HALogbookEntry[]> {
    const timestamp = startTime || new Date(Date.now() - 86400000).toISOString();
    const params = entityId ? `?entity=${entityId}` : "";
    return this.request<HALogbookEntry[]>(`/logbook/${timestamp}${params}`);
  }

  // ─── Camera ──────────────────────────────────────────────────────

  getCameraProxyUrl(entityId: string): string {
    return `${this.url}/api/camera_proxy/${entityId}?token=${this.token}`;
  }

  // ─── Error Log ───────────────────────────────────────────────────

  async getErrorLog(): Promise<string> {
    if (!this.isConfigured) throw new Error("HA not configured");
    const res = await fetch(`${this.url}/api/error_log`, { headers: this.headers });
    return res.text();
  }

  // ─── Convenience Methods ─────────────────────────────────────────

  async turnOn(entityId: string, data?: Record<string, any>): Promise<HAEntity[]> {
    const domain = entityId.split(".")[0];
    return this.callService(domain, "turn_on", { entity_id: entityId, ...data });
  }

  async turnOff(entityId: string): Promise<HAEntity[]> {
    const domain = entityId.split(".")[0];
    return this.callService(domain, "turn_off", { entity_id: entityId });
  }

  async toggle(entityId: string): Promise<HAEntity[]> {
    const domain = entityId.split(".")[0];
    return this.callService(domain, "toggle", { entity_id: entityId });
  }

  async setClimate(entityId: string, temperature: number, hvacMode?: string): Promise<HAEntity[]> {
    const data: Record<string, any> = { entity_id: entityId, temperature };
    if (hvacMode) data.hvac_mode = hvacMode;
    return this.callService("climate", "set_temperature", data);
  }

  async lockEntity(entityId: string): Promise<HAEntity[]> {
    return this.callService("lock", "lock", { entity_id: entityId });
  }

  async unlockEntity(entityId: string): Promise<HAEntity[]> {
    return this.callService("lock", "unlock", { entity_id: entityId });
  }

  // ─── Grouped State Helpers ───────────────────────────────────────

  async getEntitiesByDomain(domain: string): Promise<HAEntity[]> {
    const states = await this.getStates();
    return states.filter((s) => s.entity_id.startsWith(`${domain}.`));
  }

  async getAreas(): Promise<string[]> {
    // HA REST API doesn't expose areas directly — need WebSocket for that.
    // This extracts unique area hints from entity attributes.
    const states = await this.getStates();
    const areas = new Set<string>();
    states.forEach((s) => {
      if (s.attributes.area_id) areas.add(s.attributes.area_id);
    });
    return Array.from(areas);
  }
}

// Singleton export
export const ha = new HomeAssistantClient();
