/**
 * Frigate NVR API Client
 * ========================
 * Server-side only — reads FRIGATE_URL from env.
 *
 * Usage:
 *   import { frigate } from "@/lib/frigate-client";
 *   const cameras = await frigate.getCameras();
 *   const events = await frigate.getEvents();
 */

// ─── Types ───────────────────────────────────────────────────────────────────

export interface FrigateCamera {
  name: string;
  fps: number;
  detection_fps: number;
  process_fps: number;
  capture_pid: number;
  pid: number;
  ffmpeg_pid: number;
}

export interface FrigateEvent {
  id: string;
  camera: string;
  label: string;
  sub_label: string | null;
  top_score: number;
  start_time: number;
  end_time: number | null;
  has_clip: boolean;
  has_snapshot: boolean;
  thumbnail: string;
}

export interface FrigateStats {
  cameras: Record<string, FrigateCamera>;
  detection_fps: number;
  detectors: Record<string, any>;
  service: {
    uptime: number;
    version: string;
    storage: Record<string, any>;
  };
}

// ─── Client ──────────────────────────────────────────────────────────────────

class FrigateClient {
  private url: string;

  constructor() {
    this.url = process.env.FRIGATE_URL || "";
  }

  get isConfigured(): boolean {
    return Boolean(this.url);
  }

  private async request<T>(path: string): Promise<T> {
    if (!this.isConfigured) {
      throw new Error("Frigate not configured. Set FRIGATE_URL in .env.local");
    }
    const res = await fetch(`${this.url}/api${path}`, {
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) throw new Error(`Frigate API ${res.status}: ${res.statusText}`);
    return res.json();
  }

  // ─── Stats & Config ────────────────────────────────────────

  async getStats(): Promise<FrigateStats> {
    return this.request<FrigateStats>("/stats");
  }

  async getVersion(): Promise<string> {
    if (!this.isConfigured) throw new Error("Frigate not configured");
    const res = await fetch(`${this.url}/api/version`);
    return res.text();
  }

  async getConfig(): Promise<any> {
    return this.request<any>("/config");
  }

  // ─── Cameras ───────────────────────────────────────────────

  async getCameras(): Promise<Record<string, FrigateCamera>> {
    const stats = await this.getStats();
    return stats.cameras;
  }

  // ─── Events ────────────────────────────────────────────────

  async getEvents(params?: {
    camera?: string;
    label?: string;
    limit?: number;
    after?: number;
    before?: number;
    has_snapshot?: boolean;
    has_clip?: boolean;
  }): Promise<FrigateEvent[]> {
    const qs = new URLSearchParams();
    if (params?.camera) qs.set("camera", params.camera);
    if (params?.label) qs.set("label", params.label);
    if (params?.limit) qs.set("limit", String(params.limit));
    if (params?.after) qs.set("after", String(params.after));
    if (params?.before) qs.set("before", String(params.before));
    if (params?.has_snapshot !== undefined) qs.set("has_snapshot", String(params.has_snapshot ? 1 : 0));
    if (params?.has_clip !== undefined) qs.set("has_clip", String(params.has_clip ? 1 : 0));

    const query = qs.toString();
    return this.request<FrigateEvent[]>(`/events${query ? "?" + query : ""}`);
  }

  // ─── Snapshots & Clips ─────────────────────────────────────

  getSnapshotUrl(cameraName: string): string {
    return `${this.url}/api/${cameraName}/latest.jpg`;
  }

  getEventThumbnailUrl(eventId: string): string {
    return `${this.url}/api/events/${eventId}/thumbnail.jpg`;
  }

  getEventSnapshotUrl(eventId: string): string {
    return `${this.url}/api/events/${eventId}/snapshot.jpg`;
  }

  getEventClipUrl(eventId: string): string {
    return `${this.url}/api/events/${eventId}/clip.mp4`;
  }

  getLiveStreamUrl(cameraName: string): string {
    // MSE stream for browser playback
    return `${this.url}/live/webrtc/api/ws?src=${cameraName}`;
  }
}

// Singleton export
export const frigate = new FrigateClient();
