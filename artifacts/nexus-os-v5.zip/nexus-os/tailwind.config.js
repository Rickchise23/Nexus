/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["DM Sans", "system-ui", "sans-serif"],
        display: ["Outfit", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
      colors: {
        nexus: {
          deep: "#08080b",
          base: "#0c0c10",
          blue: "#60A5FA",
          green: "#6EE7B7",
          red: "#F87171",
          yellow: "#FBBF24",
          purple: "#A78BFA",
          cyan: "#67E8F9",
          orange: "#FB923C",
        },
      },
    },
  },
  plugins: [],
};
