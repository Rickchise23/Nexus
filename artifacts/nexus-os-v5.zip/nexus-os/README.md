# NEXUS OS

Your personal command center — smart home, dev tools, AI agents, all in one cockpit.

Built on Next.js 14 + Home Assistant + Claude API. Dark mode only. No emoji.

## Quick Start

```bash
git clone https://github.com/YOUR_USER/nexus-os.git
cd nexus-os
chmod +x setup.sh && ./setup.sh
npm run dev
```

Open http://localhost:3000 — runs immediately with mock data.

## Modules

| Module | What It Does |
|--------|-------------|
| **Home** | Control lights, locks, climate, fans, covers. Area-filtered entity grid + quick scenes. |
| **Energy** | Consumption vs solar chart, per-device breakdown, cost tracking. |
| **Cameras** | Frigate-powered camera grid with AI detection events + timeline. |
| **Automations** | Visual builder + toggle list for HA automations. |
| **System** | Service health with latency, HA connection test, Mac Mini hardware. |
| **Agent Bay** | ⌘J — Claude AI chat with HA tools. Natural language home control. |
| **Command Palette** | ⌘K — search, navigate, or send commands to Agent Bay. |
| **Notifications** | Toast alerts for security events, device changes, deploys. |

## Environment Variables

Copy `.env.example` → `.env.local`:

| Variable | Required | Purpose |
|----------|----------|---------|
| `ANTHROPIC_API_KEY` | Yes | Agent Bay (Claude + HA tools) |
| `HA_URL` | For HA | Home Assistant URL |
| `HA_TOKEN` | For HA | Long-lived access token |
| `CLERK keys` | For auth | Clerk publishable + secret |
| `GITHUB_TOKEN` | Optional | GitHub status |
| `VERCEL_DEPLOY_HOOK` | Optional | Deploy from Agent Bay |
| `FRIGATE_URL` | Optional | Camera feeds |
| `MQTT_URL` | Optional | MQTT broker status |

## HA Integration Architecture

**REST Proxy** (`/api/ha`) — All HA communication proxied server-side. Token never touches browser.

**SSE Streaming** (`/api/ha/stream`) — Real-time state push via Server-Sent Events. Auto-fallback to polling.

**Agent Bay** (`/api/agent/chat`) — Claude with 5 HA tools in an agentic loop.

**MCP Server** (`/api/mcp`) — Expose Nexus tools to HA Assist voice commands.

**Specialized**: `/api/ha/energy`, `/api/ha/cameras`, `/api/ha/automations`, `/api/ha/scenes`, `/api/ha/health`

## Mac Mini M4 Setup

```bash
docker compose up -d    # Starts HA + Mosquitto
npm run dev             # Nexus auto-detects HA
```

## Deploy

```bash
npx vercel
```

## Project Structure

```
nexus-os/
├── setup.sh                        — First-run setup
├── docker-compose.yml              — HA + Mosquitto stack
├── src/
│   ├── middleware.ts                — Clerk auth
│   ├── app/api/
│   │   ├── ha/route.ts             — HA REST proxy
│   │   ├── ha/stream/route.ts      — SSE streaming
│   │   ├── ha/health/route.ts      — Health check
│   │   ├── ha/energy/route.ts      — Energy data
│   │   ├── ha/cameras/route.ts     — Frigate proxy
│   │   ├── ha/automations/route.ts — Automation CRUD
│   │   ├── ha/scenes/route.ts      — Scene activation
│   │   ├── agent/chat/route.ts     — Claude + HA agentic loop
│   │   └── mcp/route.ts            — MCP for voice
│   ├── components/NexusOS.jsx      — All UI modules
│   ├── hooks/useHA.ts              — Polling hook
│   ├── hooks/useHAStream.ts        — SSE hook
│   ├── lib/ha-client.ts            — HA REST client
│   └── lib/frigate-client.ts       — Frigate client
└── 30 files total
```

Built by Rick Griffith / Ralli AI.
