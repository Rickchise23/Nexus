# Mac Mini M4 — Nexus OS Setup Guide

Everything runs on one box. Here's the order.

---

## Step 1: Install Docker Desktop

Download from https://www.docker.com/products/docker-desktop/

After install, open Docker Desktop and let it start. Verify:

```bash
docker --version
docker compose version
```

Give Docker at least **4 GB RAM** in Docker Desktop → Settings → Resources.
8 GB is better if you plan to run Frigate later.

---

## Step 2: Clone Nexus OS

```bash
cd ~
git clone https://github.com/YOUR_USER/nexus-os.git
cd nexus-os
```

Or if you unzipped from the build:
```bash
cd ~/nexus-os
```

---

## Step 3: Run the Setup Script

```bash
chmod +x setup.sh
./setup.sh
```

This installs npm dependencies, creates `.env.local`, and creates Docker volume directories.

---

## Step 4: Start Home Assistant

```bash
cd ~/nexus-os
docker compose up -d
```

This starts:
- **Home Assistant** on port 8123
- **Mosquitto MQTT** on port 1883

Check it's running:
```bash
docker ps
```

You should see `homeassistant` and `mosquitto` both running.

---

## Step 5: HA Onboarding

Open **http://localhost:8123** in your browser.

1. **Create your account** — name, username, password
2. **Set your location** — Phoenix, AZ (this affects weather, sun automations, timezone)
3. **Choose what you share** — your call, can skip everything
4. **Finish** — you're on the HA dashboard

---

## Step 6: Create a Long-Lived Access Token

This is what Nexus uses to talk to HA. Do this now:

1. Click your name/profile icon (bottom-left in HA)
2. Scroll all the way down to **"Long-Lived Access Tokens"**
3. Click **"Create Token"**
4. Name it **"Nexus OS"**
5. **Copy the token immediately** — you can't see it again

---

## Step 7: Configure Nexus

Edit your `.env.local`:

```bash
nano ~/nexus-os/.env.local
```

Add these two lines:
```
HA_URL=http://localhost:8123
HA_TOKEN=paste_your_long_token_here
```

Also add your Anthropic key for Agent Bay:
```
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

Save and exit (Ctrl+X, Y, Enter in nano).

---

## Step 8: Start Nexus

```bash
cd ~/nexus-os
npm run dev
```

Open **http://localhost:3000**

You should see:
- Top bar badge changes from **"Mock Data"** to **"HA Stream"** or **"HA Poll"**
- Home module shows your actual HA entities (might just be a few sensors at first)
- System module shows **Home Assistant: online** with your HA version
- Agent Bay (⌘J) can now control real devices

---

## Step 9: Install Ollama (Local AI)

This gives HA a local LLM for voice commands without cloud:

```bash
brew install ollama
ollama serve
```

In a new terminal:
```bash
ollama pull gemma3:4b
```

Then in HA:
1. Go to **Settings → Devices & Services → Add Integration**
2. Search for **"Ollama"**
3. Enter URL: `http://host.docker.internal:11434`
4. Select model: `gemma3:4b`

Now HA's Assist voice agent runs locally.

---

## Step 10: Add Your First Smart Devices

HA on macOS Docker has one limitation: **mDNS device discovery is limited** because Docker Desktop doesn't support host networking on Mac. This means:

**What works out of the box:**
- Any device you add by **IP address** (smart plugs with known IPs, etc.)
- **Cloud integrations** (Hue cloud, LIFX cloud, Tuya, etc.)
- **Zigbee/Thread devices** via a USB dongle plugged into the Mac Mini
- **Matter devices** via a Thread Border Router on your network
- **MQTT devices** (they connect to Mosquitto which IS exposed on port 1883)

**Easiest path to get started — pick one:**

### Option A: Cloud-connected devices (easiest)
If you already have Philips Hue, LIFX, TP-Link Kasa, Tuya, or similar:
1. HA → Settings → Devices & Services → Add Integration
2. Search for your brand
3. Link your account
4. Devices appear as entities

### Option B: Matter + Thread (best long-term)
1. Get a **Thread Border Router** — Apple TV 4K, HomePod Mini, or a standalone one
2. Buy a **Matter device** (Eve smart plug, Nanoleaf bulb, etc.)
3. Add to HA: Settings → Devices & Services → Add Integration → Matter
4. Scan the QR code on the device
5. It joins your Thread mesh, shows up in HA, shows up in Nexus

### Option C: Zigbee USB dongle (most devices supported)
1. Get a **Connect ZBT-2** USB dongle ($30)
2. Plug into Mac Mini
3. Pass through to Docker:
   ```yaml
   # Add to homeassistant service in docker-compose.yml:
   devices:
     - /dev/tty.usbmodem*:/dev/ttyACM0
   ```
4. Restart: `docker compose down && docker compose up -d`
5. HA → Settings → Add Integration → Zigbee Home Automation (ZHA)
6. Now you can pair any Zigbee device (Aqara sensors, IKEA bulbs, etc.)

---

## Step 11: Set Up Remote Access (for Vercel deployment)

When Nexus is deployed on Vercel, it needs to reach your HA instance at home.
Pick one:

### Cloudflare Tunnel (free, recommended)
```bash
brew install cloudflare/cloudflare/cloudflared
cloudflared tunnel login
cloudflared tunnel create nexus-ha
cloudflared tunnel route dns nexus-ha ha.yourdomain.com
```

Create `~/.cloudflared/config.yml`:
```yaml
tunnel: YOUR_TUNNEL_ID
credentials-file: /Users/YOU/.cloudflared/YOUR_TUNNEL_ID.json
ingress:
  - hostname: ha.yourdomain.com
    service: http://localhost:8123
  - service: http_status:404
```

Run it:
```bash
cloudflared tunnel run nexus-ha
```

Then update `.env.local` on Vercel:
```
HA_URL=https://ha.yourdomain.com
```

### Tailscale (easiest, 100 devices free)
```bash
brew install tailscale
```
Open Tailscale, sign in. Your Mac Mini gets a Tailscale IP (e.g. `100.x.x.x`).

Update Vercel env:
```
HA_URL=http://100.x.x.x:8123
```

### Nabu Casa ($75/year)
HA's official cloud service. Easiest but costs money.
Settings → Home Assistant Cloud → Subscribe.
Gives you a URL like `https://abcdef.ui.nabu.casa`

---

## Verify Everything Works

Run through this checklist:

```
[ ] Docker Desktop running
[ ] docker ps shows homeassistant + mosquitto
[ ] http://localhost:8123 loads HA dashboard
[ ] Long-lived access token created and in .env.local
[ ] npm run dev → http://localhost:3000 shows Nexus
[ ] Top bar shows "HA Stream" or "HA Poll" (not "Mock Data")
[ ] System module shows "Home Assistant: online"
[ ] Agent Bay (⌘J) → type "what devices do you see" → gets real answer
[ ] At least one device toggleable from Nexus Home module
```

---

## What's Running on Your Mac Mini

| Service | Port | Purpose |
|---------|------|---------|
| Home Assistant | 8123 | Smart home brain |
| Mosquitto MQTT | 1883 | IoT message broker |
| Ollama | 11434 | Local AI (gemma3:4b) |
| Nexus OS (dev) | 3000 | Your command center |
| Frigate (later) | 5000 | Camera NVR |

Total idle power draw: ~5-7W. The M4 is incredibly efficient.

---

## Quick Reference Commands

```bash
# Start everything
docker compose up -d && npm run dev

# Stop everything
docker compose down

# View HA logs
docker logs homeassistant -f

# Restart HA after config changes
docker restart homeassistant

# Update HA to latest
docker compose pull && docker compose up -d

# Check what's running
docker ps

# Ollama
ollama serve        # start the server
ollama list         # see installed models
ollama pull llama3  # download a new model
```
