/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Allow HA image proxying
  images: {
    remotePatterns: [
      {
        protocol: "http",
        hostname: "**",
      },
    ],
  },
  // Env vars that are safe to expose to the browser
  // HA_URL and HA_TOKEN stay server-side only
  env: {
    NEXT_PUBLIC_APP_NAME: "Nexus OS",
  },
};

module.exports = nextConfig;
