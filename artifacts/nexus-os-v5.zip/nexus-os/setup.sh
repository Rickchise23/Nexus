#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# NEXUS OS — First-Run Setup Script
# ═══════════════════════════════════════════════════════════════
# Run: chmod +x setup.sh && ./setup.sh

set -e

echo ""
echo "  ╔═══════════════════════════════════════╗"
echo "  ║           N E X U S   O S             ║"
echo "  ║       First-Run Setup Script          ║"
echo "  ╚═══════════════════════════════════════╝"
echo ""

# ─── Check Node.js ────────────────────────────────────────────
if ! command -v node &> /dev/null; then
  echo "❌ Node.js not found. Install from https://nodejs.org (v18+)"
  exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
  echo "❌ Node.js v18+ required. You have $(node -v)"
  exit 1
fi
echo "✓ Node.js $(node -v)"

# ─── Check npm ────────────────────────────────────────────────
if ! command -v npm &> /dev/null; then
  echo "❌ npm not found"
  exit 1
fi
echo "✓ npm $(npm -v)"

# ─── Check Docker (optional) ─────────────────────────────────
if command -v docker &> /dev/null; then
  echo "✓ Docker $(docker --version | grep -oP '\d+\.\d+\.\d+')"
  if command -v docker compose &> /dev/null 2>&1 || docker compose version &> /dev/null 2>&1; then
    echo "✓ Docker Compose available"
  else
    echo "⚠ Docker Compose not found — needed for HA stack"
  fi
else
  echo "⚠ Docker not installed — needed for Home Assistant"
  echo "  Install: https://www.docker.com/products/docker-desktop/"
fi

# ─── Install npm dependencies ────────────────────────────────
echo ""
echo "Installing dependencies..."
npm install
echo "✓ Dependencies installed"

# ─── Create .env.local if missing ────────────────────────────
if [ ! -f .env.local ]; then
  cp .env.example .env.local
  echo "✓ Created .env.local from template"
  echo ""
  echo "⚠ IMPORTANT: Edit .env.local with your keys:"
  echo "  - ANTHROPIC_API_KEY (required for Agent Bay)"
  echo "  - HA_URL + HA_TOKEN (for Home Assistant)"
  echo "  - CLERK keys (for auth)"
  echo ""
else
  echo "✓ .env.local already exists"
fi

# ─── Create Docker directories ───────────────────────────────
mkdir -p ha-config
mkdir -p mosquitto/config mosquitto/data mosquitto/log
mkdir -p frigate/config frigate/storage
echo "✓ Docker volume directories created"

# ─── Summary ─────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════"
echo " Setup complete! Next steps:"
echo "═══════════════════════════════════════════"
echo ""
echo " 1. Edit .env.local with your API keys"
echo ""
echo " 2. Start Nexus:"
echo "    npm run dev"
echo "    → Open http://localhost:3000"
echo ""
echo " 3. Start Home Assistant (optional):"
echo "    docker compose up -d"
echo "    → Open http://localhost:8123"
echo "    → Create a Long-Lived Access Token"
echo "    → Add HA_URL and HA_TOKEN to .env.local"
echo ""
echo " 4. Deploy to Vercel:"
echo "    npx vercel"
echo "    → Set env vars in Vercel dashboard"
echo ""
echo "═══════════════════════════════════════════"
echo ""
